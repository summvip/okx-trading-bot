#!/usr/bin/env python3
# okx_autotrader_server_fileupdate (full version)
# WARNING: This file contains embedded API credentials. Keep it secure (chmod 600).

import os, sys, time, threading, json, traceback, math, shutil
from datetime import datetime
import requests, hmac, hashlib, base64

# ----------------- SENSITIVE CREDENTIALS (embedded) -----------------
OKX_API_KEY = "baf58ca3-8bae-4cd9-909b-ebbc0af08fe7"
OKX_API_SECRET = "12C3FF8B6E2D5676B54F1C26034E9108"
OKX_API_PASSPHRASE = "qAZ136124."

TG_BOT_TOKEN = "8234866294:AAGeIC4Mt19nY2bSjDIZPFxED8RN-fW9G-s"
AUTHORIZED_TG_CHAT_ID = "7457058714"
# ----------------- END SENSITIVE CREDENTIALS -----------------

UPDATE_URL = ""  # optional raw URL to pull updates from

SYMBOL = "DOGE-USDT-SWAP"
RSI_PERIOD = 14
RSI_OVERSOLD = 35
RSI_OVERBOUGHT = 65

DRY_RUN = True
USDT_RATIO = 0.2
MIN_ORDER_USDT = 2.0
RESERVE_USDT = 0.5

POLL_INTERVAL = 60
COOLDOWN = 20

LOGFILE = "okx_autotrader_server.log"

def now(): return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
def log(msg, level="INFO", write=True):
    line = f"[{now()}] [{level}] {msg}"
    print(line, flush=True)
    if write:
        try:
            with open(LOGFILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

TG_API_BASE = f"https://api.telegram.org/bot{TG_BOT_TOKEN}"
TG_FILE_BASE = f"https://api.telegram.org/file/bot{TG_BOT_TOKEN}"

def tg_send(text):
    try:
        requests.post(f"{TG_API_BASE}/sendMessage", json={ "chat_id": AUTHORIZED_TG_CHAT_ID, "text": text }, timeout=10)
    except Exception as e:
        log("TG send failed: " + str(e), "ERROR")

def tg_get_updates(offset=None, timeout=10):
    params = {}
    if offset: params['offset'] = offset
    try:
        r = requests.get(f"{TG_API_BASE}/getUpdates", params=params, timeout=timeout)
        return r.json()
    except Exception as e:
        log("tg_get_updates error: " + str(e), "ERROR")
        return None

OKX_BASE = "https://www.okx.com"

def okx_sign(timestamp, method, request_path, body, secret):
    body_str = "" if body is None or body == "" else json.dumps(body, separators=(',', ':'))
    message = str(timestamp) + method.upper() + request_path + body_str
    mac = hmac.new(secret.encode('utf-8'), message.encode('utf-8'), hashlib.sha256)
    return base64.b64encode(mac.digest()).decode()

def okx_request(method, path, body=None, params=None):
    ts = datetime.utcnow().isoformat(timespec='milliseconds') + 'Z'
    body_str = '' if body is None else json.dumps(body, separators=(',', ':'))
    sign = okx_sign(ts, method, path, body, OKX_API_SECRET)
    headers = {
        'Content-Type': 'application/json',
        'OK-ACCESS-KEY': OKX_API_KEY,
        'OK-ACCESS-SIGN': sign,
        'OK-ACCESS-TIMESTAMP': ts,
        'OK-ACCESS-PASSPHRASE': OKX_API_PASSPHRASE
    }
    url = OKX_BASE + path
    try:
        if method.upper() == 'GET':
            r = requests.get(url, headers=headers, params=params, timeout=15)
        else:
            r = requests.request(method, url, headers=headers, data=body_str if body is not None else None, params=params, timeout=15)
        return r.status_code, r.json()
    except Exception as e:
        return None, {'error': str(e)}

def fetch_ohlcv(instId=SYMBOL, bar="5m", limit=100):
    status, resp = okx_request('GET', '/api/v5/market/candles', params={'instId': instId, 'bar': bar, 'limit': limit})
    if status != 200:
        raise RuntimeError(f"fetch_ohlcv failed: {status} {resp}")
    import pandas as pd
    df = pd.DataFrame(resp['data'], columns=['ts','open','high','low','close','vol','x','y','z'])
    df['close'] = df['close'].astype(float)
    return df

def fetch_balance_usdt():
    status, resp = okx_request('GET', '/api/v5/account/balance')
    if status != 200:
        log(f"fetch_balance failed: {status} {resp}", "ERROR")
        return 0.0
    try:
        for entry in resp.get('data', []):
            for d in entry.get('details', []):
                if d.get('ccy') == 'USDT':
                    return float(d.get('availBal') or 0)
    except Exception as e:
        log("parse balance error: " + str(e), "ERROR")
    return 0.0

def set_leverage_okx(instId, lever):
    body = {'instId': instId, 'lever': str(int(lever))}
    status, resp = okx_request('POST', '/api/v5/account/set-leverage', body=body)
    return status, resp

def place_market_order_okx(instId, tdMode, side, sz):
    body = {'instId': instId, 'tdMode': tdMode, 'side': side, 'ordType': 'market', 'sz': str(sz)}
    status, resp = okx_request('POST', '/api/v5/trade/order', body=body)
    return status, resp

_last_trade_ts = 0
def compute_rsi_from_df(df, period=RSI_PERIOD):
    import pandas as pd, numpy as np
    close = df['close'].astype(float)
    delta = close.diff()
    gain = delta.where(delta>0, 0)
    loss = -delta.where(delta<0, 0)
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    rs = avg_gain/avg_loss
    rsi = 100 - (100/(1+rs))
    return rsi

def compute_order_qty_from_usdt(usdt_amount, price, precision=6):
    qty = round(usdt_amount / price, precision)
    return qty

def evaluate_once(do_place=False):
    global _last_trade_ts
    try:
        df = fetch_ohlcv()
    except Exception as e:
        log("fetch ohlcv error: " + str(e), "ERROR")
        tg_send("❌ fetch ohlcv failed: " + str(e))
        return
    rsi = compute_rsi_from_df(df).iloc[-1]
    price = float(df['close'].iloc[-1])
    log(f"Signal check: price={price} RSI={rsi:.2f}")
    if rsi <= RSI_OVERSOLD:
        signal = 'buy'
    elif rsi >= RSI_OVERBOUGHT:
        signal = 'sell'
    else:
        log("No RSI signal; skip")
        return
    nowt = time.time()
    if nowt - _last_trade_ts < COOLDOWN:
        reason = f"cooldown active: {nowt-_last_trade_ts:.1f}s since last trade"
        log("Skip trade: " + reason)
        tg_send(f"⚠ {signal.upper()} skipped: {reason} | RSI={rsi:.2f} price={price}")
        return
    avail = fetch_balance_usdt()
    log(f"Available USDT: {avail}")
    notional = max(MIN_ORDER_USDT, (avail - RESERVE_USDT) * USDT_RATIO)
    if notional < MIN_ORDER_USDT:
        reason = "notional below MIN_ORDER_USDT"
        log("Skip trade: " + reason)
        tg_send(f"⚠ {signal.upper()} skipped: {reason} | {avail} USDT available")
        return
    qty = compute_order_qty_from_usdt(notional, price)
    if qty <= 0:
        log("Computed qty <=0, skip")
        tg_send(f"⚠ {signal.upper()} skipped: computed qty<=0 | price={price} notional={notional}")
        return
    st, resp = set_leverage_okx(SYMBOL, 3)
    log(f"Set leverage response: {st} {resp}")
    if st != 200 or (isinstance(resp, dict) and resp.get('code') not in (None, '0')):
        reason = f"leverage set failed: {st} {resp}"
        log("Skip trade: " + reason, "ERROR")
        tg_send(f"⚠ {signal.upper()} skipped: {reason}")
        return
    log(f"Ready to place: {signal} qty={qty} notional={notional} price={price} DRY_RUN={DRY_RUN}")
    if not do_place or DRY_RUN:
        tg_send(f"🟡 DRY_RUN: {signal.upper()} qty={qty} price≈{price} RSI={rsi:.2f}")
        _last_trade_ts = time.time()
        return
    status, order_resp = place_market_order_okx(SYMBOL, 'isolated', signal, qty)
    log(f"place order response: {status} {order_resp}")
    if status == 200 and isinstance(order_resp, dict) and order_resp.get('code') in (None, '0'):
        tg_send(f"✅ Order placed: {signal} qty={qty} price≈{price} order={order_resp.get('data')} RSI={rsi:.2f}")
        _last_trade_ts = time.time()
    else:
        tg_send(f"❌ Order failed: {status} {order_resp}")
        log("Order failed: " + str(order_resp), "ERROR")

_update_lock = threading.Lock()

def save_file_from_telegram(file_info, dest_path):
    file_id = file_info.get('file_id')
    if not file_id:
        return False, 'no file_id'
    try:
        r = requests.get(f"{TG_API_BASE}/getFile", params={'file_id': file_id}, timeout=10)
        j = r.json()
        if not j.get('ok'):
            return False, f"getFile failed: {j}"
        file_path = j['result']['file_path']
        dl_url = f"{TG_FILE_BASE}/{file_path}"
        r2 = requests.get(dl_url, timeout=30)
        if r2.status_code != 200:
            return False, f"download failed {r2.status_code}"
        with open(dest_path, 'wb') as f:
            f.write(r2.content)
        return True, 'saved'
    except Exception as e:
        return False, str(e)

def perform_update_and_restart(update_url=None, file_path_local=None):
    with _update_lock:
        try:
            cur = os.path.realpath(__file__)
            bak = cur + ".bak"
            shutil.copyfile(cur, bak)
            if file_path_local:
                shutil.copyfile(file_path_local, cur)
            else:
                url = update_url or UPDATE_URL
                if not url:
                    tg_send("❌ UPDATE_URL not set; aborting update.")
                    return
                tg_send("⬇️ Downloading update from URL...")
                r = requests.get(url, timeout=30)
                if r.status_code != 200:
                    tg_send(f"❌ Update download failed: HTTP {r.status_code}")
                    return
                new_code = r.text
                with open(cur, "w", encoding="utf-8") as f:
                    f.write(new_code)
            tg_send("✅ Update applied. Restarting...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as e:
            tg_send("❌ Update failed: " + str(e))
            log("Update failed: " + str(e), "ERROR")

def tg_command_worker():
    last_update_id = None
    tg_send("🤖 Command listener started")
    while True:
        try:
            res = tg_get_updates(offset=last_update_id)
            if not res or not isinstance(res, dict):
                time.sleep(2); continue
            for u in res.get('result', []):
                last_update_id = u['update_id'] + 1
                msg = u.get('message') or u.get('edited_message') or {}
                chat = msg.get('chat', {})
                chat_id = str(chat.get('id'))
                if chat_id != str(AUTHORIZED_TG_CHAT_ID):
                    log(f"Ignored command/file from unauthorized chat: {chat_id}")
                    continue
                text = msg.get('text','').strip() if isinstance(msg.get('text',''), str) else ''
                if 'document' in msg:
                    doc = msg['document']
                    file_name = doc.get('file_name', 'uploaded_script.py')
                    dest = os.path.join(os.path.dirname(os.path.realpath(__file__)), file_name)
                    ok, info = save_file_from_telegram(doc, dest)
                    if ok:
                        tg_send(f"✅ Received file {file_name}. Applying update...")
                        perform_update_and_restart(file_path_local=dest)
                    else:
                        tg_send(f"❌ Failed to save file: {info}")
                    continue
                if text:
                    log(f"Received TG command: {text}")
                if text.startswith('/start'):
                    tg_send("Bot is running. Use /status /run_once /place_once /update /stop or send a .py file to update")
                elif text.startswith('/run_once'):
                    evaluate_once(do_place=False)
                    tg_send("run_once executed (DRY_RUN mode)")
                elif text.startswith('/place_once'):
                    evaluate_once(do_place=True)
                    tg_send("place_once executed (attempted to place order)")
                elif text.startswith('/status'):
                    avail = fetch_balance_usdt()
                    tg_send(f"Status: DRY_RUN={DRY_RUN} Available USDT={avail}")
                elif text.startswith('/update'):
                    parts = text.split()
                    url = parts[1].strip() if len(parts) > 1 else UPDATE_URL
                    perform_update_and_restart(update_url=url)
                elif text.startswith('/stop'):
                    tg_send("Stopping bot (will exit process). To restart, run the script again.")
                    os._exit(0)
                else:
                    tg_send("Unknown command. Available: /status /run_once /place_once /update /stop or send .py file")
        except Exception as e:
            log("tg_command_worker loop error: " + str(e), "ERROR")
            time.sleep(2)

def main_loop():
    t = threading.Thread(target=tg_command_worker, daemon=True)
    t.start()
    tg_send("Bot started (listener thread running). Use /status /run_once /place_once /update /stop or send .py file to update")
    log("Entering main loop")
    while True:
        try:
            evaluate_once(do_place=False)
        except Exception as e:
            log("Main loop exception: " + str(e), "ERROR")
            traceback.print_exc()
            tg_send("Main loop exception: " + str(e))
        time.sleep(POLL_INTERVAL)

if __name__ == '__main__':
    log("okx_autotrader_server_fileupdate starting...")
    try:
        os.chmod(__file__, 0o600)
    except Exception:
        pass
    main_loop()
