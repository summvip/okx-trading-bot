OKX 自动交易机器人 — 服务器完整版（含内置 API 与 Telegram 更新）

包含文件:
- main.py  -> 全功能主脚本（已包含你提供的 OKX & Telegram 凭证）
- install.sh -> 一键安装（会把 main.py 复制到 /root/okx_bot 并注册 systemd）
- update.sh -> 手动更新脚本（bash update.sh /path/to/new_script.py）
- README.txt -> 本说明文件

快速部署（在服务器上）:
1) 上传 okx_bot_server.zip 到服务器（例如 /root）
   scp okx_bot_server.zip root@你的服务器IP:/root
2) 在服务器上解压并进入目录
   unzip okx_bot_server.zip -d /root/okx_bot_server
   cd /root/okx_bot_server
3) 运行安装（会创建虚拟环境并启动服务，首次以 DRY_RUN=True 运行以测试）
   bash install.sh
4) 查看日志
   journalctl -u okx_autotrader.service -f
