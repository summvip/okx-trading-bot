#!/bin/bash
set -e
if [ -z "$1" ]; then
  echo "用法: bash update.sh /path/to/new_script.py"
  exit 1
fi
TARGET_DIR="/root/okx_bot"
if [ ! -d "$TARGET_DIR" ]; then
  echo "目标目录不存在，先运行 install.sh"
  exit 1
fi
cp "$1" "$TARGET_DIR/okx_autotrader_server_fileupdate.py"
chmod 600 "$TARGET_DIR/okx_autotrader_server_fileupdate.py"
systemctl restart okx_autotrader.service
echo "已更新并重启服务"
