import os
import zipfile
import subprocess

ZIP_PATH = "update.zip"
BOT_DIR = "bot"

def apply_update():
    if os.path.exists(ZIP_PATH):
        print("🔄 检测到新版本，开始更新...")
        with zipfile.ZipFile(ZIP_PATH, 'r') as zip_ref:
            zip_ref.extractall(BOT_DIR)
        os.remove(ZIP_PATH)
        print("✅ 更新完成，重启机器人...")
        subprocess.Popen(["python3", "run.py"])
        exit()

if __name__ == "__main__":
    apply_update()
    # 启动主程序
    subprocess.Popen(["python3", os.path.join(BOT_DIR, "main.py")]).wait()
