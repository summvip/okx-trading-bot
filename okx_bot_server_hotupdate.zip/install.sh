#!/bin/bash
set -e
echo "开始安装 OKX 自动交易机器人 (服务器版)"
BASE_DIR="/root/okx_bot"
mkdir -p "$BASE_DIR"
cp main.py "$BASE_DIR/okx_autotrader_server_fileupdate.py"
cd "$BASE_DIR"
python3 -m venv venv || { echo "请先确保已安装 python3-venv"; exit 1; }
source venv/bin/activate
pip install --upgrade pip
pip install --no-cache-dir requests pandas
chmod 600 okx_autotrader_server_fileupdate.py
cat > /etc/systemd/system/okx_autotrader.service <<'SERVICE'
[Unit]
Description=OKX Autotrader Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/okx_bot
ExecStart=/root/okx_bot/venv/bin/python /root/okx_bot/okx_autotrader_server_fileupdate.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable okx_autotrader.service
systemctl start okx_autotrader.service
echo "安装完成。使用: systemctl status okx_autotrader.service 或 journalctl -u okx_autotrader.service -f 查看日志"
